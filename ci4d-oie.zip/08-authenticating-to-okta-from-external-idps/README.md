[![Okta Training](./.tour-resources/oktaeduservices.png "Okta Education Services")](https://www.okta.com/services/training/)

# Authenticating to Okta from External IdPs

This repo contains everything you need to complete the labs in this module:

- Lab 8.1: Authenticate with AD FS as an External IdP

## How to Start the Labs


These labs are guided by a VSCode plugin called CodeTour. To start Lab 1.1, first expand the **CODETOUR** tab on the lefthand side of VSCode. Then press the ![Start Tour](./.tour-resources/play.png) button next to Lab 8.1.

![Start Code Tour](./.tour-resources/start-tour.gif)
