# Customer Identity for Developers Course Repo

[![Okta Training](./oktaeduservices.png "Okta Education Services")](https://www.okta.com/services/training/)

Copyright 2022 Okta, Inc. All Rights Reserved. 

This is a container repository for all the lab repos used in the CI4D course.